<?php
session_start();
if (!isset($_SESSION['logged_in'])) {
    header('Location: login.php');
    exit;
}

$itemName = '';
$itemContent = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $itemName = $_POST['name'];
    $itemContent = $_POST['content'];

    $items = [];
    $file = fopen('pages.txt', 'r');
    while (($line = fgets($file)) !== false) {
        list($name, $content) = explode('|', trim($line));
        if ($name !== $itemName) {
            $items[$name] = $content;
        }
    }
    fclose($file);

    // Save the new or updated item
    $items[$itemName] = $itemContent;
    $file = fopen('pages.txt', 'w');
    foreach ($items as $name => $content) {
        fwrite($file, "$name|$content\n");
    }
    fclose($file);
    header('Location: list_items.php');
    exit;
}

if (isset($_GET['name'])) {
    $itemName = $_GET['name'];
    $file = fopen('pages.txt', 'r');
    while (($line = fgets($file)) !== false) {
        list($name, $content) = explode('|', trim($line));
        if ($name === $itemName) {
            $itemContent = $content;
            break;
        }
    }
    fclose($file);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Item</title>
</head>
<body>
    <h1>Edit Item</h1>
    <form method="POST">
        <label for="name">Name:</label>
        <input type="text" name="name" value="<?php echo htmlspecialchars($itemName); ?>" required><br>
        <label for="content">Content:</label><br>
        <textarea name="content" required><?php echo htmlspecialchars($itemContent); ?></textarea><br>
        <button type="submit">Save</button>
    </form>
</body>
</html>
