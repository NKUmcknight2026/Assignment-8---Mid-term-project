<?php
session_start();

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: admin_login.php');
    exit;
}

$items = []; // Initialize items array

// Load items from a file (for example, items.txt)
if (file_exists('items.txt')) {
    $file = fopen('items.txt', 'r');
    while (($line = fgets($file)) !== false) {
        list($itemID, $itemName) = explode('|', trim($line));
        $items[] = ['id' => $itemID, 'name' => $itemName];
    }
    fclose($file);
}

// Handle deletion of an item
if (isset($_GET['delete'])) {
    $deleteID = $_GET['delete'];
    $newItems = array_filter($items, function ($item) use ($deleteID) {
        return $item['id'] !== $deleteID;
    });
    $file = fopen('items.txt', 'w');
    foreach ($newItems as $item) {
        fwrite($file, "{$item['id']}|{$item['name']}\n");
    }
    fclose($file);
    header('Location: admin_dashboard.php');
    exit;
}
?>
<!DOCTYPE html>
<html>
<a href="admin_logout.php">Logout</a>
<head>
    <title>Admin Dashboard</title>
</head>
<body>
    <h1>Admin Dashboard</h1>
    <a href="admin_creation.php">Create New Item</a>
    <h2>Items</h2>
    <ul>
        <?php foreach ($items as $item): ?>
            <li>
                <?php echo htmlspecialchars($item['name']); ?> 
                <a href="admin_editor.php?id=<?php echo $item['id']; ?>">Edit</a>
                <a href="admin_dashboard.php?delete=<?php echo $item['id']; ?>" onclick="return confirm('Are you sure you want to delete this item?');">Delete</a>
            </li>
        <?php endforeach; ?>
    </ul>
</body>
</html>
