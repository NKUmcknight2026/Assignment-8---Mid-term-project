<?php
session_start();
if (!isset($_SESSION['logged_in'])) {
    header('Location: login.php');
    exit;
}

if (isset($_GET['name'])) {
    $itemName = $_GET['name'];

    $items = [];
    $file = fopen('pages.txt', 'r');
    while (($line = fgets($file)) !== false) {
        list($name, $content) = explode('|', trim($line));
        if ($name !== $itemName) {
            $items[$name] = $content;
        }
    }
    fclose($file);

    // Save the updated items back to the file
    $file = fopen('pages.txt', 'w');
    foreach ($items as $name => $content) {
        fwrite($file, "$name|$content\n");
    }
    fclose($file);
}

header('Location: list_items.php');
exit;
?>
